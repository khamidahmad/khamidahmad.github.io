// ============Function===============
// Move Down
$('#chevron-down').click(function(){
    $('html, body').animate({
        scrollTop: $( $(this).attr('href') ).offset().top
    }, 1500);
});
// Move Top
$(document).ready(function(){
  // hide #back-top first
  $("#back-top").hide();
  // fade in #back-top
  $(function () {
      $(window).scroll(function () {
          if ($(this).scrollTop() > 400) {
              $('#back-top').fadeIn();
          } else {
              $('#back-top').fadeOut();

          }
      });
      // scroll body to 0px on click
      $('a#back-top').click(function () {
          $('body,html').animate({
              scrollTop: 0
          }, 2000);
          return false;
      });
  });
});
// Navbar Mobile
$(document).ready(function() {
  $('.bars').click(function() {
    $(".bars").addClass("active");
    $(".fa-times").addClass("active");
    $(".sidenav").removeClass("slideOut");
    $(".sidenav").addClass("slideIn");
  })
})
$(document).ready(function() {
  $('.fa-times').click(function(){
    $(".bars").removeClass("active");
    $(".fa-times").removeClass("active");
    $(".sidenav").addClass("slideOut");
  })
})
// ============Animation===============
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
  $(window).scroll(function() {
    $(".slideanimX").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slideX");
        }
    });
  });
  $(window).scroll(function() {
    $(".slideanimLeft").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slideLeft");
        }
    });
  });
// Brochure popup
// $(document).ready(function(){
//             setTimeout(function(){
//             if(!Cookies.get('modalShown')) {
//               $("#ebrochure").modal('show');
//               Cookies.set('modalShown', true);
//             } else {
              
//             }
              
//     },3000);
//  });
// $(document).ready(function() {
//   setTimeout(function() {
//       $('#ebrochure').modal();
//   }, 5000);
// })
// ============Carousel===============
$(document).ready(function() {
  $('.one-carousel').addClass('owl-carousel owl-theme').owlCarousel({
    margin: 0,
    responsiveClass: true,
    responsive:{
      0: {
        items: 1,
        navText: ["<img src='./images/arrow-left.png'>","<img src='.images/arrow-right.png'>"],
        dots: true,
        nav: true
      },
      600: {
        items: 1,
        navText: ["<img src='./images/arrow-left.png'>","<img src='.images/arrow-right.png'>"],
        dots: true,
        nav: true
      },
      1000: {
        items: 1,
        navText: ["<img src='./images/arrow-left.png'>","<img src='./images/arrow-right.png'>"],
        dots: false,
        nav: true
      }
    }
  })
  $('.two-carousel').addClass('owl-carousel owl-theme').owlCarousel({
    margin: 0,
    responsiveClass: true,
    responsive:{
      0: {
        items: 1,
        navText: ["<img src='./images/arrow-left.png'>","<img src='.images/arrow-right.png'>"],
        dots: true,
        nav: true
      },
      600: {
        items: 1,
        navText: ["<img src='./images/arrow-left.png'>","<img src='.images/arrow-right.png'>"],
        dots: true,
        nav: true
      },
      1000: {
        items: 2,
        navText: ["<img src='./images/arrow-left.png'>","<img src='./images/arrow-right.png'>"],
        dots: false,
        nav: true
      }
    }
  })
  $('.facilities-carousel').addClass('owl-carousel owl-theme').owlCarousel({
    margin: 0,
    responsiveClass: true,
    navText: ["<img src='./images/arrow-left.png'>","<img src='./images/arrow-right.png'>"],
    responsive:{
      0: {
        items: 1,
        dots: true,
        nav: true
      },
      600: {
        items: 1,
        dots: true,
        nav: true
      },
      1000: {
        items: 1,
        dots: false,
        nav: true
      }
    }
  })
  $('.developer-carousel').addClass('owl-carousel owl-theme').owlCarousel({
    margin: 0,
    responsiveClass: true,
    navText: ["<img src='./images/arrow-left.png'>","<img src='./images/arrow-right.png'>"],
    responsive:{
      0: {
        items: 1,
        dots: true,
        nav: true
      },
      600: {
        items: 1,
        dots: true,
        nav: true
      },
      1000: {
        items: 1,
        dots: false,
        nav: true
      }
    }
  })
  $('.stagepad-carousel').addClass('owl-carousel owl-theme').owlCarousel({
    responsiveClass: true,
    navText: ["<img src='./images/arrow-left.png'>","<img src='.images/arrow-right.png'>"],
    responsive:{
      0: {
        items: 1,
        dots: true,
        nav: true
      },
      600: {
        items: 1,
        dots: true,
        nav: true
      },
      1024: {
        items: 1,
        center: true,
        margin: 50,
        stagePadding: 200,
        // autoplay: true,
        loop: true,
        dots: false,
        nav: true
      },
      1100: {
        items: 1,
        center: true,
        margin: 100,
        stagePadding: 400,
        autoplay: true,
        loop: true,
        dots: false,
        nav: true
      }
    }
  })
  $('.stagepadloc-carousel').addClass('owl-carousel owl-theme').owlCarousel({
    responsiveClass: true,
    navText: ["<img src='http://vasakabali.com/wp-content/themes/vasaka/images/icon/arrow-green-left.png'>","<img src='http://vasakabali.com/wp-content/themes/vasaka/images/icon/arrow-green-right.png'>"],
    responsive:{
      0: {
        items: 1,
        center: true,
        margin: 25,
        stagePadding: 60,
        loop: true,
        dots: true,
        nav: true
      },
      600: {
        items: 1,
        dots: true,
        nav: true
      },
      1000: {
        items: 1,
        dots: false,
        nav: true
      }
    }
  })
})
// ============Instagram===============
var token = '7205075604.1677ed0.cb89519e5cdf4f8d8e8aaee3acc06289',
    num_photos = 3;
 
$.ajax({
  url: 'https://api.instagram.com/v1/users/self/media/recent',
  dataType: 'jsonp',
  type: 'GET',
  data: {access_token: token, count: num_photos},
  // var photoURL = data[i].images.standard_resolution.url;
  // var photoLink = data[i].link;
  // var username = data[i].user.username;
  success: function(data){
    console.log(data);
    for( x in data.data ){
      $('div.instafeed').append('<div class="col-lg-4 zi-lg-100 slideanim"><a href="'+data.data[x].link+'" target="_blank"><img class="img-fluid box-shadow w-80 mb-mp-10" src="'+data.data[x].images.standard_resolution.url+'"></a></div>');
    }
  },
  error: function(data){
    console.log(data);
  }
});
var token = '7205075604.1677ed0.cb89519e5cdf4f8d8e8aaee3acc06289',
    num_photos = 4;
 
$.ajax({
  url: 'https://api.instagram.com/v1/users/self/media/recent',
  dataType: 'jsonp',
  type: 'GET',
  data: {access_token: token, count: num_photos},
  success: function(data){
    console.log(data);
    for( x in data.data ){
      $('div.instafeed2').append('<div class="col-6 pb-mp-10 pl-mp-5 pr-mp-5 slideanim"><a href="'+data.data[x].link+'" target="_blank"><img class="img-fluid box-shadow" src="'+data.data[x].images.standard_resolution.url+'"/></div>');
    }
  },
  error: function(data){
    console.log(data);
  }
});